package cn.edu.pku.ss.eventProcessor;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import cn.edu.pku.ss.bean.DIALocationMessage;
import cn.edu.pku.ss.exception.LoginFailure;
import cn.edu.pku.ss.exception.MessageFormatError;
import cn.edu.pku.ss.util.WebSocket;
import dk.itu.infobus.ws.Listener;
import dk.itu.infobus.ws.ListenerToken;


public class EventProcessor {
	URI uri;
	WebSocket ws;
	String username;
	String password;
	boolean conn = false;
	public EventProcessor(String s,String username,String password) {
		try {
			uri = new URI(s);
			ws = new WebSocket(uri);
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.username = username;
		this.password = password;
	}
	public void init() throws LoginFailure {
		try {
			ws.connect();
			ws.send("connect:"+username+" "+password);
			byte[] bs = ws.recv();
			String s = new String(bs);
			if(!s.equals("successful")) {
				ws.close();
				throw new LoginFailure();
			}
			conn =true;
			System.out.println("Login Successfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public boolean addEventGenerator(String topic) throws LoginFailure, MessageFormatError {
		if(!conn)
			throw new LoginFailure();
		try {
			ws.send("addGenerator:topic="+topic);
			byte[] bs = ws.recv();
			String ss = new String(bs);
			if(ss.equals("Wrong message")) {
				//ws.close();
				throw new MessageFormatError();
			}
			else if(ss.equals("Successful")) {
				System.out.println("Successful");
				return true;
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	public boolean addListener(final DIAListener listener,String eql) throws LoginFailure {
		if(!conn)
			throw new LoginFailure();
		try {
			
			ws.send("addListener:pattern="+eql);
			Thread t = new Thread(){
				public void run() {
					System.out.println("Listener Start!!");
					while(true) {
						byte[] bs;
						try {
							bs = ws.recv();
							System.out.println("Received: "+bs);
							String ss = new String(bs);
							if(ss.equals("CleanUp")) {
								return;
							}
							else if(ss.equals("Start")) {
								listener.onStarted();
							}
							else if(ss.equals("CleanUp")) {
								try {
									listener.cleanUp();
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
							else {
								System.out.println(ss);
								Gson gson = new Gson();
								Type type = new TypeToken<Map<String, String>>(){}.getType();
								Map<String, String> ms= gson.fromJson(ss, type);
								 type = new TypeToken<String>(){}.getType();
								String t =   (String)(ms.get("Temperarture"));
								System.out.println(t);
								listener.onMessage(ms);
						}
						}catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						
					}
				}
			};
			t.start();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
		public boolean addListener(final DIAListener listener,List<DIAListenerToken>  pattern) throws LoginFailure {
		if(!conn)
			throw new LoginFailure();
		try {
			
			 Gson gson = new Gson();
	         Type type = new TypeToken<List<DIAListenerToken>>(){}.getType();
	         String json = gson.toJson(pattern,type);
			ws.send("addListener:pattern="+json);
			Thread t = new Thread(){
				public void run() {
					System.out.println("Listener Start!!");
					while(true) {
						byte[] bs;
						try {
							bs = ws.recv();
							System.out.println("Received: "+bs);
							String ss = new String(bs);
							if(ss.equals("CleanUp")) {
								return;
							}
							else if(ss.equals("Start")) {
								listener.onStarted();
							}
							else if(ss.equals("CleanUp")) {
								try {
									listener.cleanUp();
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
							else {
								System.out.println(ss);
								Gson gson = new Gson();
								Type type = new TypeToken<Map<String, String>>(){}.getType();
								Map<String, String> ms= gson.fromJson(ss, type);
								String t =   (String)(ms.get("topic"));
								System.out.println(t);
								listener.onMessage(ms);
						}
						}catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						
					}
				}
			};
			t.start();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
}
