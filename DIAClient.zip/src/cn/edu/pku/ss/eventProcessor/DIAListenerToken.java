package cn.edu.pku.ss.eventProcessor;

import java.lang.reflect.Type;

import dk.itu.infobus.ws.ListenerToken;
import dk.itu.infobus.ws.PatternOperator;

public class DIAListenerToken {
	String fieldName;
	PatternOperator operator;
	Object value;
	public DIAListenerToken() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DIAListenerToken(String fieldName, PatternOperator operator,
			Object value) {
		super();
		this.fieldName = fieldName;
		this.operator = operator;
		this.value = value;
	}
	public DIAListenerToken( String fieldName, PatternOperator operator ) {
		this.fieldName =fieldName;
		this.operator = operator;
		this.value = null;
	}
	public DIAListenerToken( String fieldName, Object value ) {
		this(fieldName, PatternOperator.EQ, value);
	}
	public String getFieldName() {
		return fieldName;
	}
	public PatternOperator getOperator() {
		return operator;
	}
	public Object getValue() {
		return value;
	}
	
}
