package cn.edu.pku.ss.eventProcessor;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.google.gson.Gson;

import dk.itu.infobus.ws.ListenerToken;
import dk.itu.infobus.ws.PatternBuilder;
import dk.itu.infobus.ws.PatternOperator;

public class DIAPatternBuilder {
	List<DIAListenerToken> pattern = new ArrayList<DIAListenerToken>();
	public DIAPatternBuilder add(DIAListenerToken token) {
		pattern.add(token);
		return this;
	}
	public DIAPatternBuilder add(String fieldName, PatternOperator operator, Object value) {
		pattern.add(new DIAListenerToken(fieldName,operator,value));
		return this;
	}
	public DIAPatternBuilder addMatchAll(String fieldName) {
		pattern.add(new DIAListenerToken(fieldName,PatternOperator.ANY));
		return this;
	}
	public DIAPatternBuilder addUndefined(String fieldName) {
		pattern.add(new DIAListenerToken(fieldName,PatternOperator.UNDEF));
		return this;
	}
	
	public List<DIAListenerToken> getPattern() {
		return pattern;
	}
	@SuppressWarnings("unchecked")
	public static List<ListenerToken<?>> getEBPattern(List<DIAListenerToken> list) {
		PatternBuilder p =new PatternBuilder();
		for(int i=0;i<list.size();i++) {
			DIAListenerToken t = list.get(i);
			class DIAComparable implements Comparable {
				Object object;
				
				public DIAComparable(Object o) {
					super();
					this.object = o;
				}

				public int compareTo(Object o) {
					// TODO Auto-generated method stub
					if(object instanceof Comparable) {
						return ((Comparable)object).compareTo(o);
					}
					return 0;
				}

				@Override
				public boolean equals(Object obj) {
					// TODO Auto-generated method stub
					return object.equals(obj);
				}

				@Override
				public String toString() {
					// TODO Auto-generated method stub
					return object.toString();
				}
				
			}
			Comparable c = new DIAComparable(t.value);
			p.add(t.fieldName, t.operator, c);
		}
		return p.getPattern();
	}
	public void reset() {
		pattern.clear();
	}
}
