package cn.edu.pku.ss.bean;

import java.util.Map;

public class DIALocationMessage  extends DIAMessage {
	String zoneLocation;
	String coordinates;
	public DIALocationMessage(String createTime, String diveiceID,
			String diveiceName, int eventTimeOut, String eventType,
			String gatewayID, String location, String messageID, String occurTime,
			int priority, String sensorID, String topic, String vension,String zoneLocation,String coordinates) {
		super(createTime, diveiceID, diveiceName, eventTimeOut, eventType, gatewayID,
				location, messageID, occurTime, priority, sensorID, topic, vension);
		// TODO Auto-generated constructor stub
		this.coordinates = coordinates;
		this.zoneLocation = zoneLocation;
	}
	public DIALocationMessage(Map<String,Object>map) {
		this((String)map.get("CreateTime"),(String)map.get("DeviceID"),(String)map.get("DeviceName"),new Integer(map.get("EventTimeOut").toString()).intValue(),(String)map.get("eventType"),(String)map.get("GatewayID"),(String)map.get("Location")
				,(String)map.get("MessageID"),(String)map.get("OccurTime"),new Integer(map.get("Priority").toString()).intValue(),(String)map.get("SensorID")
				,(String)map.get("Topic"),(String)map.get("Vension"),(String)map.get("ZoneLocation"),(String)map.get("Coordinates"));
	}


	public DIALocationMessage() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DIALocationMessage(String createTime, String diveiceID,
			String diveiceName, int eventTimeOut, String eventType,
			String getwayID, String location, String messageID,
			String occurTime, int priority, String sensorID, String topic,
			String vension) {
		super(createTime, diveiceID, diveiceName, eventTimeOut, eventType, getwayID,
				location, messageID, occurTime, priority, sensorID, topic, vension);
		// TODO Auto-generated constructor stub
	}



	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
//	private static final long serialVersionUID = 1380187218126085110L;
	public String getZoneLocation() {
		return zoneLocation;
	}
	public String getCoordinates() {
		return coordinates;
	}



}
