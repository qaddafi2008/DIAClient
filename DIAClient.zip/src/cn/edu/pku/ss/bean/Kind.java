package cn.edu.pku.ss.bean;

public class Kind {
	public static final int bySensorName=0;
	public static final int bySensorID=1;
	public static final int byZoneName=2;
}
