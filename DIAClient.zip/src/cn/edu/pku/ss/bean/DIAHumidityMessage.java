package cn.edu.pku.ss.bean;

import java.util.Map;

public class DIAHumidityMessage extends DIAMessage {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4715321712576609304L;
	double humidity;
	public DIAHumidityMessage(String createTime, String diveiceID,
			String diveiceName, int eventTimeOut, String eventType,
			String getwayID, String location, String messageID, String occurTime,
			int priority, String sensorID, String topic, String vension,double value) {
		super(createTime, diveiceID, diveiceName, eventTimeOut, eventType, getwayID,
				location, messageID, occurTime, priority, sensorID, topic, vension);
		// TODO Auto-generated constructor stub
		this.humidity = value;
	}
	public DIAHumidityMessage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DIAHumidityMessage(Map<String,Object>map) {
		this((String)map.get("CreateTime"),(String)map.get("DeviceID"),(String)map.get("DeviceName"),new Integer(map.get("EventTimeOut").toString()).intValue(),(String)map.get("eventType"),(String)map.get("GatewayID"),(String)map.get("Location")
				,(String)map.get("MessageID"),(String)map.get("OccurTime"),new Integer(map.get("Priority").toString()).intValue(),(String)map.get("SensorID")
				,(String)map.get("Topic"),(String)map.get("Vension"),new Double(map.get("Humidity").toString()).doubleValue());
	}
	public double getHumidity() {
		return humidity;
	}
	
}
