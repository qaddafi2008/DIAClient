package cn.edu.pku.ss.bean;

import java.util.Date;

public class DIATemperatureMessage extends DIAMessage {
	double temperature;
	public DIATemperatureMessage(String createTime, String diveiceID,
			String diveiceName, int eventTimeOut, String eventType,
			String getwayID, String location, String messageID, String occurTime,
			int priority, String sensorID, String topic, String vension,double value) {
		super(createTime, diveiceID, diveiceName, eventTimeOut, eventType, getwayID,
				location, messageID, occurTime, priority, sensorID, topic, vension);
		// TODO Auto-generated constructor stub
		this.temperature = value;
	}
	
	public DIATemperatureMessage() {
		super();
		// TODO Auto-generated constructor stub
	}


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public double getTemperature() {
		return temperature;
	}
	
}
