package cn.edu.pku.ss.bean;

import java.io.Serializable;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class DIAMessage  implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String createTime;
	String getwayID;
	String sensorID;
	String messageID;
	String diveiceID;
	String vension;
	String topic;
	String eventType;
	int priority;
	String location;
	String occurTime;
	int eventTimeOut;
	String diveiceName;
	Map<String,Object> extendElements = new java.util.concurrent.ConcurrentHashMap<String, Object>();

	public DIAMessage() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DIAMessage(String createTime, String diveiceID, String diveiceName,
			int eventTimeOut, String eventType, String getwayID,
			String location, String messageID, String occurTime, int priority,
			String sensorID, String topic, String vension) {
		super();
		this.createTime = createTime;
		this.diveiceID = diveiceID;
		this.diveiceName = diveiceName;
		this.eventTimeOut = eventTimeOut;
		this.eventType = eventType;
		this.getwayID = getwayID;
		this.location = location;
		this.messageID = messageID;
		this.occurTime = occurTime;
		this.priority = priority;
		this.sensorID = sensorID;
		this.topic = topic;
		this.vension = vension;
	}
	public String getDiveiceID() {
		return diveiceID;
	}
	public String getDiveiceName() {
		return diveiceName;
	}
	public String getCreateTime() {
		return createTime;
	}
	public String getGetwayID() {
		return getwayID;
	}
	public String getSensorID() {
		return sensorID;
	}
	public String getMessageID() {
		return messageID;
	}
	public String getVension() {
		return vension;
	}
	public String getTopic() {
		return topic;
	}
	public String getEventType() {
		return eventType;
	}
	public int getPriority() {
		return priority;
	}
	public String getLocation() {
		return location;
	}
	public String getOccurTime() {
		return occurTime;
	}
	public int getEventTimeOut() {
		return eventTimeOut;
	}
	public Map<String,Object> getExtendElements() {
		return extendElements;
	}

	
}
