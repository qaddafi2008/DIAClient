package cn.edu.pku.ss.starter;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import cn.edu.pku.ss.eventProcessor.DIAListenerToken;
import cn.edu.pku.ss.eventProcessor.DIAPatternBuilder;

import dk.itu.infobus.ws.EventBuilder;
import dk.itu.infobus.ws.EventBus;
import dk.itu.infobus.ws.Generator;
import dk.itu.infobus.ws.GeneratorAdapter;
import dk.itu.infobus.ws.Listener;
import dk.itu.infobus.ws.ListenerToken;
import dk.itu.infobus.ws.PatternBuilder;
import dk.itu.infobus.ws.PatternOperator;
import dk.itu.infobus.ws.Util;

public class TestEB {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Generator sampleGenerator;
		 Listener sampleListener;
		EventBus eb= new EventBus("tiger.itu.dk", 8004);
		try {
			eb.start();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		sampleGenerator =  new GeneratorAdapter(
			    "Topic.Temperature",  // the name of the generator is the first argument to the constructor
			    "TempeRature","bar","baz"){   // then a variable-length list of strings identifies the fields
			protected void onStarted() throws Exception {
		        // when the generator starts, create a thread
		        Thread t = new Thread(){
		            public void run() {
		                EventBuilder eb = new EventBuilder();
		                int[] bars = {0,5,10,15,20,25,30,35,40};
		                int[] bazs = {0,1,2,3,4,5,6,7,8};
		                int i = 0;
		                while(true) {
		                    eb.reset(); // calling reset simply discard the current map
		                    try {
		                        Thread.sleep(500); //sleep for half second
		                        publish(eb.put("TempeRature",25)
		                                .put("bar", bars[i])
		                                .put("baz", bazs[i])
		                                .getEvent());
		                            } catch(Exception e){}
		                            // just update the i variable to iterate on the bars and bazs arrays
		                            i = (i+1) % bars.length;
		                        }
		                    };
		                };
		                t.start();
		            }
		        };
		        sampleListener = new Listener(
		                new PatternBuilder()
		                .add("TempeRature", PatternOperator.NEQ, 20)
		               /* .add("bar", PatternOperator.NEQ, 20)
		                .add("baz", PatternOperator.GT, 5)*/
		                .getPattern()){
		        	public void cleanUp() throws Exception {
		            }
		            public void onStarted() {
		                System.out.println("Listener started!");
		            }
		            public void onMessage(Map<String, Object> msg) {
		                Util.traceEvent(msg);
		            }
		        };

		        try {
					eb.addListener(sampleListener);
					 eb.addGenerator(sampleGenerator);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			   
		        }
	}


