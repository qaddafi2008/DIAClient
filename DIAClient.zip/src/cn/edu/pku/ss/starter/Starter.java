package cn.edu.pku.ss.starter;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import cn.edu.pku.ss.bean.DIAHumidityMessage;
import cn.edu.pku.ss.bean.DIALocationMessage;
import cn.edu.pku.ss.bean.DIATemperatureMessage;
import cn.edu.pku.ss.bean.Kind;
import cn.edu.pku.ss.controller.DIAController;
import cn.edu.pku.ss.eventProcessor.DIAListener;
import cn.edu.pku.ss.eventProcessor.DIAListenerToken;
import cn.edu.pku.ss.eventProcessor.DIAPatternBuilder;
import cn.edu.pku.ss.eventProcessor.EventProcessor;
import cn.edu.pku.ss.exception.LoginFailure;
import cn.edu.pku.ss.exception.MessageFormatError;
import cn.edu.pku.ss.provider.DIAProvider;
import cn.edu.pku.ss.util.Util;
import dk.itu.infobus.ws.Listener;
import dk.itu.infobus.ws.ListenerToken;
import dk.itu.infobus.ws.PatternBuilder;
import dk.itu.infobus.ws.PatternOperator;

public class Starter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DIAController c = new DIAController("ws://localhost:8080/DIAServer/core-socket","wilson","1234");
		try {
			c.init();
			c.sendCommand("123456789021", "on");
		} catch (LoginFailure e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (MessageFormatError e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		return;
/*		DIAProvider p = new DIAProvider("ws://localhost:8080/DIAServer/core-socket","wilson","1234");
		try {
			p.init();
			try {
				
				List<DIALocationMessage> list =p.getLocation("chuweijie-Iphone4", Kind.bySensorName);
				if(list != null) {
					System.out.println(list.get(0).getZoneLocation());
				}
				else {
					System.out.println("null");
				}
				list =p.getLocation("123456789021", Kind.bySensorID);
				if(list != null) {
					
					System.out.println(list.get(0).getZoneLocation());
				}
				else {
					System.out.println("null");
				}
				list = p.getLocation("5205", Kind.byZoneName);
				if(list != null) {
					
					System.out.println(list.get(0).getZoneLocation());
					System.out.println(list.size());
				}
				else {
					System.out.println("null");
				}
				
				List<DIATemperatureMessage> list2 = p.getTemperature("5205", Kind.byZoneName);
				if(list2 != null) {
					System.out.println(list2.get(0).getTemperature());
				}
				else {
					System.out.println("null");
				}
				list2 = p.getTemperature("123456789012", Kind.bySensorID);
				if(list2 != null) {
					System.out.println(list2.get(0).getTemperature());
				}
				else {
					System.out.println("null");
				}
				List<DIAHumidityMessage> list3 = p.getHumidity("5205", Kind.byZoneName);
				if(list3 != null) {
					System.out.println(list3.get(0).getHumidity());
				}
				else {
					System.out.println("null");
				}
				list3 = p.getHumidity("123456789231", Kind.bySensorID);
				if(list3 != null) {
					System.out.println(list3.get(0).getHumidity());
				}
				else {
					System.out.println("null");
				}
			} catch (MessageFormatError e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (LoginFailure e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		EventProcessor ep = new EventProcessor("ws://localhost:8080/DIAServer/core-socket","wilson","1234");
		try {
			ep.init();
			ep.addEventGenerator("Temperature");
		} catch (LoginFailure e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (MessageFormatError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		DIAListener l = new DIAListener(){
			public void cleanUp() throws Exception {
            }
            public void onStarted() {
                System.out.println("Listener started!");
            }
            public void onMessage(Map<String, String> msg) {
                Util.traceEvent(msg);
            	//Open Air Conditioning to let the room cool down
            }

	};
	try {
		ep.addListener(l, "Select * From Temperature where Temperature > 10");
	} catch (LoginFailure e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/

	}

}
