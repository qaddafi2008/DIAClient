package cn.edu.pku.ss.exception;

public class LoginFailure extends Exception {

}
