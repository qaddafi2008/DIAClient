package cn.edu.pku.ss.exception;

public class MessageFormatError extends Exception {

}
