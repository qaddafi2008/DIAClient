package cn.edu.pku.ss.provider;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import cn.edu.pku.ss.bean.DIAHumidityMessage;
import cn.edu.pku.ss.bean.DIALocationMessage;
import cn.edu.pku.ss.bean.DIATemperatureMessage;
import cn.edu.pku.ss.exception.LoginFailure;
import cn.edu.pku.ss.exception.MessageFormatError;
import cn.edu.pku.ss.util.WebSocket;

public class DIAProvider {
	URI uri;
	WebSocket ws;
	String username;
	String password;
	boolean conn = false;
	public DIAProvider(String wsurl,String username,String password) {
		try {
			uri = new URI(wsurl);
			ws = new WebSocket(uri);
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.username = username;
		this.password = password;
	}
	public void init() throws LoginFailure {
		try {
			ws.connect();
			ws.send("connect:"+username+" "+password);
			byte[] bs = ws.recv();
			String s = new String(bs);
			if(!s.equals("successful")) {
				ws.close();
				throw new LoginFailure();
			}
			conn =true;
			System.out.println("Login Successfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public List<DIALocationMessage> getLocation(String s,int kind) throws LoginFailure,MessageFormatError {
		if(!conn)
			throw new LoginFailure();
		try {
			ws.send("query:topic=Location&kind="+kind+"&key="+s);
			byte[] bs = ws.recv();
			String ss = new String(bs);
			if(ss.equals("Wrong message")) {
				//ws.close();
				throw new MessageFormatError();
			}
			else if(ss.equals("null")) {
				return null;
			}
			else {
				Gson gson = new Gson();
				Type type = new TypeToken<List<DIALocationMessage>>(){}.getType();
				List<DIALocationMessage> list = gson.fromJson(ss, type);
				return list;
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	public List<DIATemperatureMessage> getTemperature(String s,int kind) throws LoginFailure, MessageFormatError {
		if(!conn)
			throw new LoginFailure();
		try {
			ws.send("query:topic=Temperature&kind="+kind+"&key="+s);
			byte[] bs = ws.recv();
			String ss = new String(bs);
			if(ss.equals("Wrong message")) {
				//ws.close();
				throw new MessageFormatError();
			}
			else if(ss.equals("null")) {
				return null;
			}
			else {
				Gson gson = new Gson();
				Type type = new TypeToken<List<DIATemperatureMessage>>(){}.getType();
				List<DIATemperatureMessage> list = gson.fromJson(ss, type);
				return list;
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	public List<DIAHumidityMessage> getHumidity(String s,int kind) throws LoginFailure, MessageFormatError {
		if(!conn)
			throw new LoginFailure();
		try {
			ws.send("query:topic=Humidity&kind="+kind+"&key="+s);
			byte[] bs = ws.recv();
			String ss = new String(bs);
			if(ss.equals("Wrong message")) {
				//ws.close();
				throw new MessageFormatError();
			}
			else if(ss.equals("null")) {
				return null;
			}
			else {
				Gson gson = new Gson();
				Type type = new TypeToken<List<DIAHumidityMessage>>(){}.getType();
				List<DIAHumidityMessage> list = gson.fromJson(ss, type);
				return list;
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

}
